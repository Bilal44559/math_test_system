@extends('frontend.layouts.app')
@section('title')
    Terms
@endsection
@section('content')
    <p>Terms & conditions</p>
@endsection
@section('footer')
@endsection
