<footer class="footer py-3">
    <div class="container-fluid">
        <div class="row align-items-center justify-content-lg-between">
            <div class="col-lg-6 mb-lg-0 mb-4 mx-auto">
                <div class="copyright text-center text-sm text-muted text-lg-start">
                    ©
                    <script>
                        document.write(new Date().getFullYear())
                    </script>,
                    <a href="{{ route('home') }}" class="font-weight-bold text-navy" target="_blank">Math Skills for School
                        Success</a>
                </div>
            </div>
        </div>
    </div>
</footer>
